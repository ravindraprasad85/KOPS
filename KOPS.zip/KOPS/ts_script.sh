#!/bin/bash
n1=$(kubectl get nodes -o wide | grep node | awk '{print $7}'|head -n 1)
n2=$(kubectl get nodes -o wide | grep node | awk '{print $7}'|tail -n 1)
ssh -t -o StrictHostKeyChecking=no admin@$n1 "sudo chmod 777 /opt/kubernetes/helpers/docker-healthcheck && echo docker-health-check > /opt/kubernetes/helpers/docker-healthcheck"
ssh -t -o StrictHostKeyChecking=no admin@$n2 "sudo chmod 777 /opt/kubernetes/helpers/docker-healthcheck && echo docker-health-check > /opt/kubernetes/helpers/docker-healthcheck"
ssh -t -o StrictHostKeyChecking=no admin@$n1 "sudo systemctl stop docker"
ssh -t -o StrictHostKeyChecking=no admin@$n2 "sudo systemctl stop docker"
